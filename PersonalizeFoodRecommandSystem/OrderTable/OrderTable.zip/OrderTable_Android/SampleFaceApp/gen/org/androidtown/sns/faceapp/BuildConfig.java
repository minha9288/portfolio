/** Automatically generated file. DO NOT MODIFY */
package org.androidtown.sns.faceapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}