import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;


public class SimilarSearchMgr {
	private DBConnectionMgr pool;
	
	public SimilarSearchMgr() {
		try {
			pool = DBConnectionMgr.getInstance();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//������ �ൿ���� ���� ã��
	public Vector<UserBean> getSimilarTypePeople(int c_point_challenge, int c_point_stable, int c_point_healthy, int c_point_price) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		boolean flag = false;
		Vector<UserBean> user_list = new Vector<UserBean>();
		try {	
			//������ ���� �޾ƿ���
			con=pool.getConnection();
			sql="select * from user where user_type=1 order by rand() limit ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, c_point_challenge);
			rs = pstmt.executeQuery();	
			while(rs.next()){
				UserBean bean = new UserBean();
				bean.setUser_id(rs.getString(1));
				bean.setUser_nation(rs.getString(2));
				bean.setUser_sex(rs.getInt(3));
				bean.setUser_age(rs.getInt(4));
				bean.setPoint_challenge(rs.getInt(5));
				bean.setPoint_stable(rs.getInt(6));
				bean.setPoint_healthy(rs.getInt(7));
				bean.setPoint_price(rs.getInt(8));
				bean.setUser_type(rs.getInt(9));
				user_list.add(bean);
				System.out.print("id : " + bean.getUser_id() + " / ");
				System.out.print("nation : " + bean.getUser_nation() + " / ");
				System.out.print("sex : " + bean.getUser_sex() + " / ");
				System.out.print("age : " + bean.getUser_age() + " / ");
				System.out.print("challenge : " + bean.getPoint_challenge() + " / ");
				System.out.print("stable : " + bean.getPoint_stable() + " / ");
				System.out.print("healthy : " + bean.getPoint_healthy() + " / ");
				System.out.print("price : " + bean.getPoint_price());
				System.out.println("");
			}
			
			//������ ���� �޾ƿ���
			sql="select * from user where user_type=2 order by rand() limit ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, c_point_stable);
			rs = pstmt.executeQuery();
			while(rs.next()){
				UserBean bean = new UserBean();
				bean.setUser_id(rs.getString(1));
				bean.setUser_nation(rs.getString(2));
				bean.setUser_sex(rs.getInt(3));
				bean.setUser_age(rs.getInt(4));
				bean.setPoint_challenge(rs.getInt(5));
				bean.setPoint_stable(rs.getInt(6));
				bean.setPoint_healthy(rs.getInt(7));
				bean.setPoint_price(rs.getInt(8));
				bean.setUser_type(rs.getInt(9));
				user_list.add(bean);
			}

			//�ǰ��� ���� �޾ƿ���
			sql="select * from user where user_type=3 order by rand() limit ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, c_point_healthy);
			rs = pstmt.executeQuery();
			while(rs.next()){
				UserBean bean = new UserBean();
				bean.setUser_id(rs.getString(1));
				bean.setUser_nation(rs.getString(2));
				bean.setUser_sex(rs.getInt(3));
				bean.setUser_age(rs.getInt(4));
				bean.setPoint_challenge(rs.getInt(5));
				bean.setPoint_stable(rs.getInt(6));
				bean.setPoint_healthy(rs.getInt(7));
				bean.setPoint_price(rs.getInt(8));
				bean.setUser_type(rs.getInt(9));
				user_list.add(bean);
			}

			//������ ���� �޾ƿ���
			sql="select * from user where user_type=4 order by rand() limit ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, c_point_price);
			rs = pstmt.executeQuery();
			while(rs.next()){
				UserBean bean = new UserBean();
				bean.setUser_id(rs.getString(1));
				bean.setUser_nation(rs.getString(2));
				bean.setUser_sex(rs.getInt(3));
				bean.setUser_age(rs.getInt(4));
				bean.setPoint_challenge(rs.getInt(5));
				bean.setPoint_stable(rs.getInt(6));
				bean.setPoint_healthy(rs.getInt(7));
				bean.setPoint_price(rs.getInt(8));
				bean.setUser_type(rs.getInt(9));
				user_list.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return user_list;
	}
	
	//������ ���׷���Ÿ�� ���� ã��
		public Vector<UserBean> getSimilarStreoPeople(String c_user_nation, int c_user_sex, int c_user_age, int rate_nation, int rate_sex, int rate_age){
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = null;
			Vector<UserBean> user_list = new Vector<UserBean>();
			try {	
				//���� ��ġ ���� �޾ƿ���
				con=pool.getConnection();
				sql="select * from user where user_nation=? order by rand() limit ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, c_user_nation);
				pstmt.setInt(2, rate_nation/2);
				rs = pstmt.executeQuery();	
				while(rs.next()){
					UserBean bean = new UserBean();
					bean.setUser_id(rs.getString(1));
					bean.setUser_nation(rs.getString(2));
					bean.setUser_sex(rs.getInt(3));
					bean.setUser_age(rs.getInt(4));
					bean.setPoint_challenge(rs.getInt(5));
					bean.setPoint_stable(rs.getInt(6));
					bean.setPoint_healthy(rs.getInt(7));
					bean.setPoint_price(rs.getInt(8));
					bean.setUser_type(rs.getInt(9));
					user_list.add(bean);
				}
				
				//���� ��ġ ���� �޾ƿ���
				sql="select * from user where user_sex=? order by rand() limit ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, c_user_sex);
				pstmt.setInt(2, rate_sex/2);
				rs = pstmt.executeQuery();
				while(rs.next()){
					UserBean bean = new UserBean();
					bean.setUser_id(rs.getString(1));
					bean.setUser_nation(rs.getString(2));
					bean.setUser_sex(rs.getInt(3));
					bean.setUser_age(rs.getInt(4));
					bean.setPoint_challenge(rs.getInt(5));
					bean.setPoint_stable(rs.getInt(6));
					bean.setPoint_healthy(rs.getInt(7));
					bean.setPoint_price(rs.getInt(8));
					bean.setUser_type(rs.getInt(9));
					user_list.add(bean);
				}

				//���� ���� ���� �޾ƿ���
				sql="select * from user where user_age=? order by rand() limit ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, c_user_age);
				pstmt.setInt(2, rate_age/2);
				rs = pstmt.executeQuery();
				while(rs.next()){
					UserBean bean = new UserBean();
					bean.setUser_id(rs.getString(1));
					bean.setUser_nation(rs.getString(2));
					bean.setUser_sex(rs.getInt(3));
					bean.setUser_age(rs.getInt(4));
					bean.setPoint_challenge(rs.getInt(5));
					bean.setPoint_stable(rs.getInt(6));
					bean.setPoint_healthy(rs.getInt(7));
					bean.setPoint_price(rs.getInt(8));
					bean.setUser_type(rs.getInt(9));
					user_list.add(bean);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con, pstmt);
			}
			return user_list;
		}
	

}
