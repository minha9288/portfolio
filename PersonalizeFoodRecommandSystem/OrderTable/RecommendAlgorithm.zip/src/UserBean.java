
public class UserBean {
	
	private String user_id;
	private String user_nation;
	private int user_sex;  //M=0, W=1
	private int user_age;
	private int point_challenge;  //0~100
	private int point_stable;  //0~100
	private int point_healthy;  //0~100
	private int point_price;  //0~100
	private int user_type;  //basic=0, challenge=1, stable=2, healthy=3, price=4
	
	
	public String getUser_id() {
		return user_id;
	}
	public String getUser_nation() {
		return user_nation;
	}
	public int getUser_sex() {
		return user_sex;
	}
	public int getUser_age() {
		return user_age;
	}
	public int getPoint_challenge() {
		return point_challenge;
	}
	public int getPoint_stable() {
		return point_stable;
	}
	public int getPoint_healthy() {
		return point_healthy;
	}
	public int getPoint_price() {
		return point_price;
	}
	public int getUser_type() {
		return user_type;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public void setUser_nation(String user_nation) {
		this.user_nation = user_nation;
	}
	public void setUser_sex(int user_sex) {
		this.user_sex = user_sex;
	}
	public void setUser_age(int user_age) {
		this.user_age = user_age;
	}
	public void setPoint_challenge(int point_challenge) {
		this.point_challenge = point_challenge;
	}
	public void setPoint_stable(int point_stable) {
		this.point_stable = point_stable;
	}
	public void setPoint_healthy(int point_healthy) {
		this.point_healthy = point_healthy;
	}
	public void setPoint_price(int point_price) {
		this.point_price = point_price;
	}
	public void setUser_type(int user_type) {
		this.user_type = user_type;
	}
	
	

}
