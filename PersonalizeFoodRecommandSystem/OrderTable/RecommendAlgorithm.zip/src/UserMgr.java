import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;


public class UserMgr {
	private DBConnectionMgr pool;
	
	public UserMgr() {
		try {
			pool = DBConnectionMgr.getInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//id�������� Ȯ��
	public boolean idChecking(String c_user_id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		boolean flag = false;
		try {
			con = pool.getConnection();
			sql = "select user_id from user where user_id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, c_user_id); 
			rs = pstmt.executeQuery();
			flag = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt, rs);
		}
		return flag;
	}
	
	
	//���ο� User�߰�
	public boolean insertUser(UserBean bean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {			
			con=pool.getConnection();
			sql="insert user (user_id, user_nation, user_sex, user_age, point_challenge, point_stable, point_healthy, point_price, user_type)" + "values(?,?,?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, bean.getUser_id());
			pstmt.setString(2, bean.getUser_nation());
			pstmt.setInt(3, bean.getUser_sex());
			pstmt.setInt(4, bean.getUser_age());
			pstmt.setInt(5, bean.getPoint_challenge());
			pstmt.setInt(6, bean.getPoint_stable());
			pstmt.setInt(7, bean.getPoint_healthy());
			pstmt.setInt(8, bean.getPoint_price());
			pstmt.setInt(9, bean.getUser_type());
			if(pstmt.executeUpdate()==1) 
				flag=true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con, pstmt);
		}
		return flag;
	}
	
	//User ���� �޾ƿ�
	public UserBean getUser(String c_user_id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		UserBean bean = null;
		try {
			con = pool.getConnection();
			String sql = "select * from user where user_id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, c_user_id);
			rs = pstmt.executeQuery();			
			if (rs.next()) {
				bean = new UserBean();
				bean.setUser_id(rs.getString("user_id"));
				bean.setUser_nation(rs.getString("user_nation"));
				bean.setUser_sex(rs.getInt("user_sex"));
				bean.setUser_age(rs.getInt("user_age"));
				bean.setPoint_challenge(rs.getInt("point_challenge"));
				bean.setPoint_stable(rs.getInt("point_stable"));
				bean.setPoint_healthy(rs.getInt("point_healthy"));
				bean.setPoint_price(rs.getInt("point_price"));
				bean.setUser_type(rs.getInt("user_type"));
			}else
				System.out.println("������??");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con);
		}
		return bean;
	}
	
	public String getUserType(String c_user_id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String type = "";
		try {
			con = pool.getConnection();
			String sql = "select * from user where user_id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, c_user_id);
			rs = pstmt.executeQuery();			
			if (rs.next()) {
				type = rs.getString("user_type");
			}else
				System.out.println("������??");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pool.freeConnection(con);
		}
		return type;
	}
	
	/*
	//User ���� �ֹ����� ���� �޾ƿ�
		public Vector<UserOrderedBean> getUserOrdered(String c_user_id) {
			Connection con = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			Vector<UserOrderedBean> user_ordered_list = new Vector<UserOrderedBean>();
			try {
				con = pool.getConnection();
				String sql = "select * from user_ordered where user_id=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, c_user_id);
				rs = pstmt.executeQuery();			
				if (rs.next()) {
					UserOrderedBean bean = new UserOrderedBean();
					bean.setUser_id(rs.getString("user_id"));
					bean.setUser_nation(rs.getString("user_nation"));
					bean.setUser_sex(rs.getInt("user_sex"));
					bean.setUser_age(rs.getInt("user_age"));
					bean.setPoint_challenge(rs.getInt("point_challenge"));
					bean.setPoint_stable(rs.getInt("point_stable"));
					bean.setPoint_healthy(rs.getInt("point_healthy"));
					bean.setPoint_price(rs.getInt("point_price"));
					bean.setUser_type(rs.getInt("user_type"));
					user_ordered_list.add(bean);
				}else
					System.out.println("������??");
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				pool.freeConnection(con);
			}
			return user_ordered_list;
		}
		
		
		//���� ���� ���� �޾ƿ���
		sql="select * from user where user_age=? order by rand() limit ?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, c_user_age);
		pstmt.setInt(2, rate_age/2);
		rs = pstmt.executeQuery();
		while(rs.next()){
			UserBean bean = new UserBean();
			bean.setUser_id(rs.getString(1));
			bean.setUser_nation(rs.getString(2));
			bean.setUser_sex(rs.getInt(3));
			bean.setUser_age(rs.getInt(4));
			bean.setPoint_challenge(rs.getInt(5));
			bean.setPoint_stable(rs.getInt(6));
			bean.setPoint_healthy(rs.getInt(7));
			bean.setPoint_price(rs.getInt(8));
			bean.setUser_type(rs.getInt(9));
			user_list.add(bean);
		}
		
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		pool.freeConnection(con, pstmt);
	}
	return user_list;
}
	*/

}
