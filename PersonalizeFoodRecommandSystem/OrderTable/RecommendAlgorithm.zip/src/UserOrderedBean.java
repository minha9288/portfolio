
public class UserOrderedBean {

	private String user_id;
	private String ordered_name;
	private String ordered_material;  
	private int ordered_price;
	private int ordered_star;  //1~3
	
	public String getOrdered_name() {
		return ordered_name;
	}
	public void setOrdered_name(String ordered_name) {
		this.ordered_name = ordered_name;
	}
	
	
	
}
