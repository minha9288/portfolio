
public class UserBean {
	
	private String user_id;
	private String user_nation;
	private String user_sex;  //M=0, W=1
	private int user_age;
	private String user_type;
	
	
	public String getUser_id() {
		return user_id;
	}
	public String getUser_nation() {
		return user_nation;
	}
	public String getUser_sex() {
		return user_sex;
	}
	public int getUser_age() {
		return user_age;
	}
	public String getUser_type() {
		return user_type;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public void setUser_nation(String user_nation) {
		this.user_nation = user_nation;
	}
	public void setUser_sex(String user_sex) {
		this.user_sex = user_sex;
	}
	public void setUser_age(int user_age) {
		this.user_age = user_age;
	}
	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}
	
	

}
